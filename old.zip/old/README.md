# api-ConsultaCNPJ
Uma API para consultar CNPJ  na receita federal <br/>
Link do Figma do projeto: https://www.figma.com/file/0MgUu1bzldOUVtTZ5QfRfV/Consulta_CNPJ?node-id=0%3A1&t=FmJj6Co0s56vEFef-0
